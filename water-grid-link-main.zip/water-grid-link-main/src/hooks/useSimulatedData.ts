import { useState, useEffect, useCallback, useRef } from "react";

export interface PumpStatus {
  primary: "ON" | "OFF" | "FAULT";
  backup: "ON" | "OFF" | "STANDBY";
  autoSwitched: boolean;
  runtime: number; // hours
}

export interface LocationData {
  id: string;
  name: string;
  tankLevel: number; // 0-100%
  waterPressure: number; // bar
  pipePressure: number; // bar
  pump: PumpStatus;
  dryRunProtection: boolean;
  flowRate: number; // L/min
}

export interface Alert {
  id: string;
  timestamp: Date;
  location: string;
  type: "info" | "warning" | "critical";
  message: string;
  notified: boolean;
  notificationMethod?: "SMS" | "Email";
}

export interface HistoryPoint {
  time: string;
  tankLevel: number;
  waterPressure: number;
  pipePressure: number;
  flowRate: number;
  pumpActive: boolean;
}

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
const rand = (min: number, max: number) => Math.random() * (max - min) + min;

function generateHistory(count: number): HistoryPoint[] {
  const points: HistoryPoint[] = [];
  let level = rand(40, 80);
  let wp = rand(2, 4);
  let pp = rand(1.5, 3.5);
  let fr = rand(100, 300);

  for (let i = 0; i < count; i++) {
    const h = i % 24;
    const timeStr = `${String(h).padStart(2, "0")}:00`;
    level = clamp(level + rand(-5, 5), 10, 95);
    wp = clamp(wp + rand(-0.3, 0.3), 1, 5);
    pp = clamp(pp + rand(-0.2, 0.2), 1, 4.5);
    fr = clamp(fr + rand(-20, 20), 50, 400);
    points.push({
      time: timeStr,
      tankLevel: Math.round(level * 10) / 10,
      waterPressure: Math.round(wp * 100) / 100,
      pipePressure: Math.round(pp * 100) / 100,
      flowRate: Math.round(fr),
      pumpActive: level < 80,
    });
  }
  return points;
}

function createLocation(id: string, name: string): LocationData {
  return {
    id,
    name,
    tankLevel: rand(30, 85),
    waterPressure: rand(2, 4),
    pipePressure: rand(1.5, 3.5),
    pump: {
      primary: "ON",
      backup: "STANDBY",
      autoSwitched: false,
      runtime: rand(100, 2000),
    },
    dryRunProtection: false,
    flowRate: rand(100, 300),
  };
}

function updateLocation(loc: LocationData): { updated: LocationData; newAlerts: Omit<Alert, "id">[] } {
  const alerts: Omit<Alert, "id">[] = [];
  const delta = rand(-3, 3);
  let tankLevel = clamp(loc.tankLevel + delta, 5, 98);
  let waterPressure = clamp(loc.waterPressure + rand(-0.2, 0.2), 0.5, 5.5);
  let pipePressure = clamp(loc.pipePressure + rand(-0.15, 0.15), 0.5, 5);
  let flowRate = clamp(loc.flowRate + rand(-15, 15), 30, 450);
  let pump = { ...loc.pump };
  let dryRunProtection = false;

  // Simulate pump fault (~2% chance)
  if (pump.primary === "ON" && Math.random() < 0.02) {
    pump.primary = "FAULT";
    pump.backup = "ON";
    pump.autoSwitched = true;
    alerts.push({
      timestamp: new Date(),
      location: loc.name,
      type: "critical",
      message: `Primary pump failure at ${loc.name}! Backup pump auto-activated.`,
      notified: true,
      notificationMethod: "SMS",
    });
  }

  // Recovery from fault (~10% chance)
  if (pump.primary === "FAULT" && Math.random() < 0.1) {
    pump.primary = "ON";
    pump.backup = "STANDBY";
    pump.autoSwitched = false;
    alerts.push({
      timestamp: new Date(),
      location: loc.name,
      type: "info",
      message: `Primary pump restored at ${loc.name}. Backup on standby.`,
      notified: true,
      notificationMethod: "Email",
    });
  }

  // Low water warning
  if (tankLevel < 20) {
    alerts.push({
      timestamp: new Date(),
      location: loc.name,
      type: "warning",
      message: `Low water level at ${loc.name}: ${tankLevel.toFixed(1)}%`,
      notified: true,
      notificationMethod: "SMS",
    });
  }

  // Critical low water
  if (tankLevel < 10) {
    dryRunProtection = true;
    alerts.push({
      timestamp: new Date(),
      location: loc.name,
      type: "critical",
      message: `Dry-run protection activated at ${loc.name}! Pump stopped.`,
      notified: true,
      notificationMethod: "SMS",
    });
  }

  // Abnormal pressure
  if (waterPressure > 4.5 || pipePressure > 4) {
    alerts.push({
      timestamp: new Date(),
      location: loc.name,
      type: "warning",
      message: `Abnormal pressure detected at ${loc.name}: Water ${waterPressure.toFixed(2)} bar, Pipe ${pipePressure.toFixed(2)} bar`,
      notified: true,
      notificationMethod: "Email",
    });
  }

  pump.runtime += 1 / 3600; // add ~1 second

  return {
    updated: {
      ...loc,
      tankLevel,
      waterPressure,
      pipePressure,
      flowRate,
      pump,
      dryRunProtection,
    },
    newAlerts: alerts,
  };
}

export function useSimulatedData() {
  const [locationA, setLocationA] = useState(() => createLocation("a", "Location A"));
  const [locationB, setLocationB] = useState(() => createLocation("b", "Location B"));
  const [alerts, setAlerts] = useState<Alert[]>(() => {
    // Seed with some initial alerts
    return [
      {
        id: "init-1",
        timestamp: new Date(Date.now() - 300000),
        location: "Location A",
        type: "info" as const,
        message: "System started. All sensors online.",
        notified: false,
      },
      {
        id: "init-2",
        timestamp: new Date(Date.now() - 120000),
        location: "Location B",
        type: "warning" as const,
        message: "Minor pressure fluctuation detected at Location B.",
        notified: true,
        notificationMethod: "Email" as const,
      },
    ];
  });
  const [historyA] = useState(() => generateHistory(24));
  const [historyB] = useState(() => generateHistory(24));
  const alertCounter = useRef(10);

  useEffect(() => {
    const interval = setInterval(() => {
      const resultA = updateLocation(locationA);
      const resultB = updateLocation(locationB);
      setLocationA(resultA.updated);
      setLocationB(resultB.updated);

      const newAlerts = [...resultA.newAlerts, ...resultB.newAlerts].map((a) => ({
        ...a,
        id: `alert-${alertCounter.current++}`,
      }));
      if (newAlerts.length > 0) {
        setAlerts((prev) => [...newAlerts, ...prev].slice(0, 100));
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [locationA, locationB]);

  const systemHealth = useCallback(() => {
    const issues: string[] = [];
    if (locationA.pump.primary === "FAULT" || locationB.pump.primary === "FAULT") issues.push("Pump fault");
    if (locationA.tankLevel < 20 || locationB.tankLevel < 20) issues.push("Low water");
    if (locationA.dryRunProtection || locationB.dryRunProtection) issues.push("Dry-run active");
    if (locationA.waterPressure > 4.5 || locationB.waterPressure > 4.5) issues.push("High pressure");

    if (issues.some((i) => i === "Pump fault" || i === "Dry-run active")) return "critical" as const;
    if (issues.length > 0) return "warning" as const;
    return "healthy" as const;
  }, [locationA, locationB]);

  return {
    locationA,
    locationB,
    alerts,
    historyA,
    historyB,
    systemHealth: systemHealth(),
  };
}

export function useAnalyticsData() {
  const [data] = useState(() => {
    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    return days.map((day) => ({
      day,
      flowA: Math.round(rand(5000, 12000)),
      flowB: Math.round(rand(4000, 11000)),
      pressureA: Math.round(rand(25, 40) * 10) / 10,
      pressureB: Math.round(rand(20, 38) * 10) / 10,
      runtimeA: Math.round(rand(8, 22) * 10) / 10,
      runtimeB: Math.round(rand(6, 20) * 10) / 10,
    }));
  });

  const uptime = { a: rand(95, 99.9), b: rand(93, 99.5) };

  return { weeklyData: data, uptime };
}
