import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LocationData } from "@/hooks/useSimulatedData";
import { Droplets, Gauge, Activity, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "react-router-dom";

interface StatusCardProps {
  location: LocationData;
}

export default function StatusCard({ location }: StatusCardProps) {
  const pumpColor =
    location.pump.primary === "ON"
      ? "text-success"
      : location.pump.primary === "FAULT"
      ? "text-destructive animate-blink"
      : "text-muted-foreground";

  return (
    <Link to={`/location/${location.id}`}>
      <Card className="bg-card border-border hover:glow-cyan transition-shadow duration-300 cursor-pointer group">
        <CardHeader className="pb-2">
          <CardTitle className="text-foreground flex items-center justify-between">
            <span className="font-mono">{location.name}</span>
            {location.dryRunProtection && (
              <span className="text-xs bg-destructive/20 text-destructive px-2 py-0.5 rounded animate-blink">
                DRY-RUN
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Tank Level */}
          <div className="space-y-1">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground flex items-center gap-1">
                <Droplets className="h-3.5 w-3.5 text-primary" /> Tank Level
              </span>
              <span className="font-mono text-foreground">{location.tankLevel.toFixed(1)}%</span>
            </div>
            <div className="h-3 bg-secondary rounded-full overflow-hidden">
              <div
                className={cn(
                  "h-full rounded-full transition-all duration-1000",
                  location.tankLevel > 50
                    ? "bg-primary"
                    : location.tankLevel > 20
                    ? "bg-warning"
                    : "bg-destructive"
                )}
                style={{ width: `${location.tankLevel}%` }}
              />
            </div>
          </div>

          {/* Pump Status */}
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground flex items-center gap-1">
              <Zap className="h-3.5 w-3.5" /> Pump
            </span>
            <div className="flex items-center gap-2">
              <span className={cn("font-mono font-bold", pumpColor)}>
                {location.pump.primary}
              </span>
              {location.pump.autoSwitched && (
                <span className="text-xs text-warning">(Backup)</span>
              )}
            </div>
          </div>

          {/* Pressures */}
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="bg-secondary/50 rounded p-2">
              <div className="text-muted-foreground flex items-center gap-1 text-xs">
                <Gauge className="h-3 w-3" /> Water
              </div>
              <div className="font-mono text-foreground mt-0.5">
                {location.waterPressure.toFixed(2)} <span className="text-xs text-muted-foreground">bar</span>
              </div>
            </div>
            <div className="bg-secondary/50 rounded p-2">
              <div className="text-muted-foreground flex items-center gap-1 text-xs">
                <Activity className="h-3 w-3" /> Pipe
              </div>
              <div className="font-mono text-foreground mt-0.5">
                {location.pipePressure.toFixed(2)} <span className="text-xs text-muted-foreground">bar</span>
              </div>
            </div>
          </div>

          {/* Flow Rate */}
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Flow Rate</span>
            <span className="font-mono text-foreground">
              {location.flowRate.toFixed(0)} <span className="text-xs text-muted-foreground">L/min</span>
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
