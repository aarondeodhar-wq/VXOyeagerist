import { LocationData } from "@/hooks/useSimulatedData";
import { cn } from "@/lib/utils";

interface Props {
  locationA: LocationData;
  locationB: LocationData;
}

export default function PipelineDiagram({ locationA, locationB }: Props) {
  return (
    <div className="relative bg-card border border-border rounded-lg p-6 overflow-hidden">
      <div className="flex items-center justify-between relative z-10">
        {/* Location A */}
        <div className="flex flex-col items-center gap-2">
          <div className="w-16 h-24 border-2 border-primary/60 rounded-md relative overflow-hidden bg-secondary">
            <div
              className="absolute bottom-0 left-0 right-0 bg-primary/40 transition-all duration-1000"
              style={{ height: `${locationA.tankLevel}%` }}
            >
              <div className="absolute inset-0 water-gradient animate-water-flow opacity-60" />
            </div>
          </div>
          <span className="text-xs font-mono text-foreground">{locationA.name}</span>
          <span className="text-xs font-mono text-primary">{locationA.tankLevel.toFixed(0)}%</span>
        </div>

        {/* Pipeline */}
        <div className="flex-1 mx-6 relative">
          <div className="h-1 bg-border rounded-full relative overflow-hidden">
            <div className="absolute inset-0 water-gradient animate-water-flow" />
          </div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card border border-border rounded px-3 py-1">
            <span className="text-xs font-mono text-muted-foreground">~20 km</span>
          </div>
          {/* Flow dots */}
          <div className="absolute top-1/2 -translate-y-1/2 left-0 w-full flex justify-between px-8">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse-glow"
                style={{ animationDelay: `${i * 0.4}s` }}
              />
            ))}
          </div>
        </div>

        {/* Location B */}
        <div className="flex flex-col items-center gap-2">
          <div className="w-16 h-24 border-2 border-primary/60 rounded-md relative overflow-hidden bg-secondary">
            <div
              className="absolute bottom-0 left-0 right-0 bg-primary/40 transition-all duration-1000"
              style={{ height: `${locationB.tankLevel}%` }}
            >
              <div className="absolute inset-0 water-gradient animate-water-flow opacity-60" />
            </div>
          </div>
          <span className="text-xs font-mono text-foreground">{locationB.name}</span>
          <span className="text-xs font-mono text-primary">{locationB.tankLevel.toFixed(0)}%</span>
        </div>
      </div>
    </div>
  );
}
