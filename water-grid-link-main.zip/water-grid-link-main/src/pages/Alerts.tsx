import { useSimulatedData } from "@/hooks/useSimulatedData";
import { cn } from "@/lib/utils";
import { Bell, Mail, MessageSquare, AlertTriangle, Info, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Alerts() {
  const { alerts } = useSimulatedData();

  const criticalCount = alerts.filter((a) => a.type === "critical").length;
  const warningCount = alerts.filter((a) => a.type === "warning").length;
  const infoCount = alerts.filter((a) => a.type === "info").length;

  const typeConfig = {
    critical: { icon: XCircle, color: "text-destructive", bg: "bg-destructive/10 border-l-destructive", label: "Critical" },
    warning: { icon: AlertTriangle, color: "text-warning", bg: "bg-warning/10 border-l-warning", label: "Warning" },
    info: { icon: Info, color: "text-info", bg: "bg-info/10 border-l-info", label: "Info" },
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold font-mono text-foreground text-glow">
        Alerts & Notifications
      </h1>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="bg-destructive/10 border-destructive/30">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-mono font-bold text-destructive">{criticalCount}</div>
            <div className="text-xs text-muted-foreground mt-1">Critical</div>
          </CardContent>
        </Card>
        <Card className="bg-warning/10 border-warning/30">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-mono font-bold text-warning">{warningCount}</div>
            <div className="text-xs text-muted-foreground mt-1">Warnings</div>
          </CardContent>
        </Card>
        <Card className="bg-info/10 border-info/30">
          <CardContent className="p-4 text-center">
            <div className="text-3xl font-mono font-bold text-info">{infoCount}</div>
            <div className="text-xs text-muted-foreground mt-1">Info</div>
          </CardContent>
        </Card>
      </div>

      {/* Alert Feed */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="font-mono text-sm text-muted-foreground flex items-center gap-2">
            <Bell className="h-4 w-4 text-primary" /> Live Alert Feed
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-[500px] overflow-y-auto">
            {alerts.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No alerts recorded</p>
            ) : (
              alerts.map((alert) => {
                const config = typeConfig[alert.type];
                const Icon = config.icon;
                return (
                  <div
                    key={alert.id}
                    className={cn(
                      "flex items-start gap-3 p-3 rounded-md border-l-2 transition-colors",
                      config.bg
                    )}
                  >
                    <Icon className={cn("h-4 w-4 mt-0.5 shrink-0", config.color)} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={cn("text-xs font-mono font-semibold px-1.5 py-0.5 rounded", config.color)}>
                          {config.label}
                        </span>
                        <span className="text-xs text-muted-foreground font-mono">
                          {alert.location}
                        </span>
                      </div>
                      <p className="text-sm text-foreground">{alert.message}</p>
                      <div className="flex items-center gap-3 mt-1.5">
                        <span className="text-xs text-muted-foreground font-mono">
                          {alert.timestamp.toLocaleTimeString()}
                        </span>
                        {alert.notified && alert.notificationMethod && (
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            {alert.notificationMethod === "SMS" ? (
                              <MessageSquare className="h-3 w-3" />
                            ) : (
                              <Mail className="h-3 w-3" />
                            )}
                            {alert.notificationMethod} sent
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
