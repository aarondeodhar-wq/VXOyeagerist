import { useAnalyticsData } from "@/hooks/useSimulatedData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, Clock, TrendingUp, Activity } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  LineChart, Line,
} from "recharts";

const chartTooltipStyle = {
  background: "hsl(220 25% 9%)",
  border: "1px solid hsl(220 15% 18%)",
  borderRadius: "8px",
  color: "hsl(200 20% 90%)",
  fontSize: 12,
};

export default function Analytics() {
  const { weeklyData, uptime } = useAnalyticsData();

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold font-mono text-foreground text-glow">
        Analytics & Reports
      </h1>

      {/* Uptime Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <UptimeCard label="Location A Uptime" value={uptime.a} />
        <UptimeCard label="Location B Uptime" value={uptime.b} />
      </div>

      {/* Water Flow Trends */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="font-mono text-sm text-muted-foreground flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" /> Water Flow Trends (Weekly)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 18%)" />
              <XAxis dataKey="day" stroke="hsl(215 15% 55%)" fontSize={11} />
              <YAxis stroke="hsl(215 15% 55%)" fontSize={11} />
              <Tooltip contentStyle={chartTooltipStyle} />
              <Legend />
              <Bar dataKey="flowA" name="Location A" fill="hsl(190, 90%, 50%)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="flowB" name="Location B" fill="hsl(190, 70%, 35%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pump Runtime */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-mono text-sm text-muted-foreground flex items-center gap-2">
              <Clock className="h-4 w-4" /> Pump Runtime (hrs/day)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 18%)" />
                <XAxis dataKey="day" stroke="hsl(215 15% 55%)" fontSize={10} />
                <YAxis stroke="hsl(215 15% 55%)" fontSize={10} />
                <Tooltip contentStyle={chartTooltipStyle} />
                <Legend />
                <Bar dataKey="runtimeA" name="Loc A" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="runtimeB" name="Loc B" fill="hsl(142, 50%, 30%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Pressure Comparison */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-mono text-sm text-muted-foreground flex items-center gap-2">
              <Activity className="h-4 w-4" /> Pressure Comparison
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 18%)" />
                <XAxis dataKey="day" stroke="hsl(215 15% 55%)" fontSize={10} />
                <YAxis stroke="hsl(215 15% 55%)" fontSize={10} />
                <Tooltip contentStyle={chartTooltipStyle} />
                <Legend />
                <Line type="monotone" dataKey="pressureA" name="Loc A" stroke="hsl(190, 90%, 50%)" strokeWidth={2} dot />
                <Line type="monotone" dataKey="pressureB" name="Loc B" stroke="hsl(38, 92%, 50%)" strokeWidth={2} dot />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function UptimeCard({ label, value }: { label: string; value: number }) {
  const pct = value.toFixed(1);
  return (
    <Card className="bg-card border-border">
      <CardContent className="p-6 flex items-center gap-4">
        <div className="relative w-16 h-16">
          <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
            <circle cx="18" cy="18" r="16" fill="none" stroke="hsl(220 15% 18%)" strokeWidth="3" />
            <circle
              cx="18" cy="18" r="16" fill="none"
              stroke="hsl(142, 71%, 45%)"
              strokeWidth="3"
              strokeDasharray={`${value} ${100 - value}`}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-xs font-mono font-bold text-foreground">{pct}%</span>
          </div>
        </div>
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="text-2xl font-mono font-bold text-success">{pct}%</div>
        </div>
      </CardContent>
    </Card>
  );
}
