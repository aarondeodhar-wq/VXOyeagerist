import { useParams, Navigate } from "react-router-dom";
import { useSimulatedData, type HistoryPoint } from "@/hooks/useSimulatedData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Droplets, Zap, Gauge, Activity, ShieldCheck, ShieldX } from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line,
} from "recharts";

export default function LocationDetail() {
  const { id } = useParams<{ id: string }>();
  const { locationA, locationB, historyA, historyB } = useSimulatedData();

  const location = id === "a" ? locationA : id === "b" ? locationB : null;
  const history = id === "a" ? historyA : historyB;

  if (!location) return <Navigate to="/" />;

  const pumpColor =
    location.pump.primary === "ON"
      ? "text-success"
      : location.pump.primary === "FAULT"
      ? "text-destructive"
      : "text-muted-foreground";

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold font-mono text-foreground text-glow">
        {location.name} — Detail View
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tank Visualization */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-mono text-sm text-muted-foreground flex items-center gap-2">
              <Droplets className="h-4 w-4 text-primary" /> Tank Level
            </CardTitle>
          </CardHeader>
          <CardContent className="flex justify-center">
            <div className="relative w-32 h-48 border-2 border-primary/50 rounded-lg overflow-hidden bg-secondary">
              <div
                className="absolute bottom-0 left-0 right-0 transition-all duration-1000 bg-primary/30"
                style={{ height: `${location.tankLevel}%` }}
              >
                <div className="absolute inset-0 water-gradient animate-water-flow opacity-70" />
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="font-mono text-2xl font-bold text-foreground drop-shadow-lg">
                  {location.tankLevel.toFixed(1)}%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pump Control Panel */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-mono text-sm text-muted-foreground flex items-center gap-2">
              <Zap className="h-4 w-4" /> Pump Status
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-secondary/50 rounded-lg p-4 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Primary Pump</span>
                <span className={cn("font-mono font-bold text-lg", pumpColor)}>
                  {location.pump.primary}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Backup Pump</span>
                <span className={cn("font-mono font-bold",
                  location.pump.backup === "ON" ? "text-warning" : "text-muted-foreground"
                )}>
                  {location.pump.backup}
                </span>
              </div>
              {location.pump.autoSwitched && (
                <div className="text-xs text-warning bg-warning/10 rounded px-2 py-1 text-center">
                  ⚡ Auto-switched to backup
                </div>
              )}
              <div className="flex justify-between items-center text-xs text-muted-foreground">
                <span>Runtime</span>
                <span className="font-mono">{location.pump.runtime.toFixed(0)} hrs</span>
              </div>
            </div>

            {/* Dry-run protection */}
            <div className={cn(
              "flex items-center gap-2 p-3 rounded-lg border",
              location.dryRunProtection
                ? "border-destructive/50 bg-destructive/10"
                : "border-success/30 bg-success/5"
            )}>
              {location.dryRunProtection ? (
                <ShieldX className="h-5 w-5 text-destructive" />
              ) : (
                <ShieldCheck className="h-5 w-5 text-success" />
              )}
              <span className="text-sm font-mono">
                Dry-Run Protection: {location.dryRunProtection ? "ACTIVE" : "OK"}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Pressure Gauges */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-mono text-sm text-muted-foreground flex items-center gap-2">
              <Gauge className="h-4 w-4" /> Pressure Readings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <PressureMeter label="Water Pressure" value={location.waterPressure} max={6} unit="bar" />
            <PressureMeter label="Pipe Pressure" value={location.pipePressure} max={5} unit="bar" />
            <div className="flex items-center justify-between text-sm bg-secondary/50 rounded p-3">
              <span className="text-muted-foreground flex items-center gap-1">
                <Activity className="h-3.5 w-3.5 text-primary" /> Flow Rate
              </span>
              <span className="font-mono text-foreground text-lg">
                {location.flowRate.toFixed(0)} <span className="text-xs text-muted-foreground">L/min</span>
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Historical Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-mono text-sm text-muted-foreground">Tank Level History</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 18%)" />
                <XAxis dataKey="time" stroke="hsl(215 15% 55%)" fontSize={10} />
                <YAxis stroke="hsl(215 15% 55%)" fontSize={10} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(220 25% 9%)",
                    border: "1px solid hsl(220 15% 18%)",
                    borderRadius: "8px",
                    color: "hsl(200 20% 90%)",
                    fontSize: 12,
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="tankLevel"
                  stroke="hsl(190, 90%, 50%)"
                  fill="hsl(190, 90%, 50%)"
                  fillOpacity={0.15}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="font-mono text-sm text-muted-foreground">Pressure History</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={history}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 15% 18%)" />
                <XAxis dataKey="time" stroke="hsl(215 15% 55%)" fontSize={10} />
                <YAxis stroke="hsl(215 15% 55%)" fontSize={10} />
                <Tooltip
                  contentStyle={{
                    background: "hsl(220 25% 9%)",
                    border: "1px solid hsl(220 15% 18%)",
                    borderRadius: "8px",
                    color: "hsl(200 20% 90%)",
                    fontSize: 12,
                  }}
                />
                <Line type="monotone" dataKey="waterPressure" stroke="hsl(190, 90%, 50%)" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="pipePressure" stroke="hsl(38, 92%, 50%)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function PressureMeter({ label, value, max, unit }: { label: string; value: number; max: number; unit: string }) {
  const pct = (value / max) * 100;
  const color = pct > 80 ? "bg-destructive" : pct > 60 ? "bg-warning" : "bg-primary";

  return (
    <div className="space-y-1">
      <div className="flex justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-mono text-foreground">
          {value.toFixed(2)} {unit}
        </span>
      </div>
      <div className="h-2 bg-secondary rounded-full overflow-hidden">
        <div className={cn("h-full rounded-full transition-all duration-1000", color)} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
