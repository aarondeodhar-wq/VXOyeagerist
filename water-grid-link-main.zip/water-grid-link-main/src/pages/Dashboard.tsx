import StatusCard from "@/components/StatusCard";
import PipelineDiagram from "@/components/PipelineDiagram";
import { useSimulatedData } from "@/hooks/useSimulatedData";
import { cn } from "@/lib/utils";
import { Shield, ShieldAlert, ShieldX } from "lucide-react";

export default function Dashboard() {
  const { locationA, locationB, systemHealth, alerts } = useSimulatedData();

  const healthConfig = {
    healthy: { icon: Shield, label: "All Systems Normal", color: "text-success", bg: "bg-success/10 border-success/30" },
    warning: { icon: ShieldAlert, label: "Warning Active", color: "text-warning", bg: "bg-warning/10 border-warning/30" },
    critical: { icon: ShieldX, label: "Critical Alert", color: "text-destructive", bg: "bg-destructive/10 border-destructive/30 animate-pulse-glow" },
  };

  const health = healthConfig[systemHealth];
  const HealthIcon = health.icon;
  const recentAlerts = alerts.slice(0, 3);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold font-mono text-foreground text-glow">
          System Overview
        </h1>
        <div className={cn("flex items-center gap-2 px-4 py-2 rounded-lg border", health.bg)}>
          <HealthIcon className={cn("h-5 w-5", health.color)} />
          <span className={cn("font-mono text-sm font-semibold", health.color)}>{health.label}</span>
        </div>
      </div>

      {/* Pipeline Diagram */}
      <PipelineDiagram locationA={locationA} locationB={locationB} />

      {/* Location Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <StatusCard location={locationA} />
        <StatusCard location={locationB} />
      </div>

      {/* Recent Alerts */}
      <div className="bg-card border border-border rounded-lg p-4">
        <h3 className="font-mono text-sm text-muted-foreground mb-3">Recent Alerts</h3>
        {recentAlerts.length === 0 ? (
          <p className="text-sm text-muted-foreground">No recent alerts</p>
        ) : (
          <div className="space-y-2">
            {recentAlerts.map((alert) => (
              <div
                key={alert.id}
                className={cn(
                  "flex items-start gap-3 text-sm p-2 rounded border-l-2",
                  alert.type === "critical" && "border-l-destructive bg-destructive/5",
                  alert.type === "warning" && "border-l-warning bg-warning/5",
                  alert.type === "info" && "border-l-info bg-info/5"
                )}
              >
                <span className="text-xs font-mono text-muted-foreground whitespace-nowrap">
                  {alert.timestamp.toLocaleTimeString()}
                </span>
                <span className="text-foreground">{alert.message}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
