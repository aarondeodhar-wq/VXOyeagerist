

# 💧 Smart IoT Water Grid Dashboard

A visually impressive hackathon demo dashboard for monitoring and controlling water distribution between two locations (~20 km apart), with simulated real-time IoT data.

## Page 1: Main Dashboard (Overview)

- **Interactive map/diagram** showing Location A and Location B connected by a pipeline
- **Live status cards** for each location showing:
  - Tank water level (animated gauge/progress bar)
  - Pump status (ON/OFF/FAULT with color indicators)
  - Water pressure level
  - Pipe pressure level
- **Real-time clock** showing current monitoring time
- **System health summary** — green/yellow/red overall status indicator
- Data auto-refreshes every few seconds with simulated sensor values

## Page 2: Location Detail View

- Dedicated detailed view for Location A or Location B
- **Tank visualization** — animated water level filling/draining
- **Pump control panel** — Primary pump status + Backup pump with auto-switch indicator
- **Pressure gauges** — visual meters for water and pipe pressure
- **Historical charts** (line/area charts) showing water level, pressure, and pump activity over time
- **Dry-run protection indicator** — shows if pump would be automatically stopped

## Page 3: Alerts & Notifications Log

- **Live alert feed** showing warnings and critical events:
  - Low water level warnings
  - Pump failure detected → backup activated
  - Abnormal pressure readings
  - Dry-run protection triggered
- **Simulated SMS/Email notification log** — shows what notifications would be sent to operators
- Color-coded severity levels (info, warning, critical)
- Timestamp and location for each alert

## Page 4: Analytics & Reports

- **Water flow trends** — charts showing water distribution patterns over days
- **Pump runtime statistics** — how long each pump has been running
- **Pressure comparison** — Location A vs Location B pressure trends
- **System uptime** — percentage uptime visualization

## Design & UX

- Dark theme with blue/cyan accents (industrial IoT feel)
- Animated gauges, flowing water indicators, and pulsing status lights
- Responsive layout (works on projector for hackathon presentation)
- Smooth transitions and real-time data simulation for wow-factor

## Technical Approach

- All data is **simulated** with realistic random values that change over time
- No backend needed — everything runs in the browser
- Charts built with Recharts for professional data visualization

